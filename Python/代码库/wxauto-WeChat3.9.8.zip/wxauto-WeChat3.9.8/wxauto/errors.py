
class TargetNotFoundError(Exception):
    pass