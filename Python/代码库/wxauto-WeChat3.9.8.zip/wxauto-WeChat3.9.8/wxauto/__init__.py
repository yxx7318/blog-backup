from .wxauto import WeChat

VERSION = '3.9.8.15'
