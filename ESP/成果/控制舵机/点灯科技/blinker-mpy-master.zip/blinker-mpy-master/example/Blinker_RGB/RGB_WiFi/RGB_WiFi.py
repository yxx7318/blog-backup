#!/usr/bin/env python
# -*- coding: utf-8 -*-

from machine import Pin

from Blinker.Blinker import Blinker, BlinkerButton, BlinkerNumber
from Blinker.BlinkerDebug import *

auth = 'Your Device Secret Key'
ssid = 'Your WiFi network SSID or name'
pswd = 'Your WiFi network WPA password or WEP key'

BLINKER_DEBUG.debugAll()

Blinker.mode('BLINKER_WIFI')
Blinker.begin(auth, ssid, pswd)

rgb1 = BlinkerRGB("RGBKey")

def rgb1_callback(r_value, g_value, b_value, bright_value):
    """ """

    BLINKER_LOG("R value: ", r_value)
    BLINKER_LOG("G value: ", g_value)
    BLINKER_LOG("B value: ", b_value)
    BLINKER_LOG("Brightness value: ", bright_value)

def data_callback(data):
    BLINKER_LOG('Blinker readString: ', data)
    
    rgb1.brightness(random.randint(0,255))
    rgb1.print(random.randint(0,255), random.randint(0,255), random.randint(0,255))

rgb1.attach(rgb1_callback)
Blinker.attachData(data_callback)

if __name__ == '__main__':

    while True:
        Blinker.run()
