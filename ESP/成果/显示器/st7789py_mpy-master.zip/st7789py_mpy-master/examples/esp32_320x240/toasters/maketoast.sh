#!/bin/sh

sprites2bitmap.py toasters.bmp 64 64 4  >toast_bitmaps.py
